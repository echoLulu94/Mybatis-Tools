package com.cmos.mmp.beans.phonecard;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class employeeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public employeeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andJobIdIsNull() {
            addCriterion("JOB_ID is null");
            return (Criteria) this;
        }

        public Criteria andJobIdIsNotNull() {
            addCriterion("JOB_ID is not null");
            return (Criteria) this;
        }

        public Criteria andJobIdEqualTo(String value) {
            addCriterion("JOB_ID =", value, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdNotEqualTo(String value) {
            addCriterion("JOB_ID <>", value, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdGreaterThan(String value) {
            addCriterion("JOB_ID >", value, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdGreaterThanOrEqualTo(String value) {
            addCriterion("JOB_ID >=", value, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdLessThan(String value) {
            addCriterion("JOB_ID <", value, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdLessThanOrEqualTo(String value) {
            addCriterion("JOB_ID <=", value, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdLike(String value) {
            addCriterion("JOB_ID like", value, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdNotLike(String value) {
            addCriterion("JOB_ID not like", value, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdIn(List<String> values) {
            addCriterion("JOB_ID in", values, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdNotIn(List<String> values) {
            addCriterion("JOB_ID not in", values, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdBetween(String value1, String value2) {
            addCriterion("JOB_ID between", value1, value2, "jobId");
            return (Criteria) this;
        }

        public Criteria andJobIdNotBetween(String value1, String value2) {
            addCriterion("JOB_ID not between", value1, value2, "jobId");
            return (Criteria) this;
        }

        public Criteria andWorkNumIsNull() {
            addCriterion("WORK_NUM is null");
            return (Criteria) this;
        }

        public Criteria andWorkNumIsNotNull() {
            addCriterion("WORK_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andWorkNumEqualTo(String value) {
            addCriterion("WORK_NUM =", value, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumNotEqualTo(String value) {
            addCriterion("WORK_NUM <>", value, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumGreaterThan(String value) {
            addCriterion("WORK_NUM >", value, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumGreaterThanOrEqualTo(String value) {
            addCriterion("WORK_NUM >=", value, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumLessThan(String value) {
            addCriterion("WORK_NUM <", value, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumLessThanOrEqualTo(String value) {
            addCriterion("WORK_NUM <=", value, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumLike(String value) {
            addCriterion("WORK_NUM like", value, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumNotLike(String value) {
            addCriterion("WORK_NUM not like", value, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumIn(List<String> values) {
            addCriterion("WORK_NUM in", values, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumNotIn(List<String> values) {
            addCriterion("WORK_NUM not in", values, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumBetween(String value1, String value2) {
            addCriterion("WORK_NUM between", value1, value2, "workNum");
            return (Criteria) this;
        }

        public Criteria andWorkNumNotBetween(String value1, String value2) {
            addCriterion("WORK_NUM not between", value1, value2, "workNum");
            return (Criteria) this;
        }

        public Criteria andNameIsNull() {
            addCriterion("NAME is null");
            return (Criteria) this;
        }

        public Criteria andNameIsNotNull() {
            addCriterion("NAME is not null");
            return (Criteria) this;
        }

        public Criteria andNameEqualTo(String value) {
            addCriterion("NAME =", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotEqualTo(String value) {
            addCriterion("NAME <>", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThan(String value) {
            addCriterion("NAME >", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameGreaterThanOrEqualTo(String value) {
            addCriterion("NAME >=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThan(String value) {
            addCriterion("NAME <", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLessThanOrEqualTo(String value) {
            addCriterion("NAME <=", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameLike(String value) {
            addCriterion("NAME like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotLike(String value) {
            addCriterion("NAME not like", value, "name");
            return (Criteria) this;
        }

        public Criteria andNameIn(List<String> values) {
            addCriterion("NAME in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotIn(List<String> values) {
            addCriterion("NAME not in", values, "name");
            return (Criteria) this;
        }

        public Criteria andNameBetween(String value1, String value2) {
            addCriterion("NAME between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andNameNotBetween(String value1, String value2) {
            addCriterion("NAME not between", value1, value2, "name");
            return (Criteria) this;
        }

        public Criteria andResNumIsNull() {
            addCriterion("RES_NUM is null");
            return (Criteria) this;
        }

        public Criteria andResNumIsNotNull() {
            addCriterion("RES_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andResNumEqualTo(String value) {
            addCriterion("RES_NUM =", value, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumNotEqualTo(String value) {
            addCriterion("RES_NUM <>", value, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumGreaterThan(String value) {
            addCriterion("RES_NUM >", value, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumGreaterThanOrEqualTo(String value) {
            addCriterion("RES_NUM >=", value, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumLessThan(String value) {
            addCriterion("RES_NUM <", value, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumLessThanOrEqualTo(String value) {
            addCriterion("RES_NUM <=", value, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumLike(String value) {
            addCriterion("RES_NUM like", value, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumNotLike(String value) {
            addCriterion("RES_NUM not like", value, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumIn(List<String> values) {
            addCriterion("RES_NUM in", values, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumNotIn(List<String> values) {
            addCriterion("RES_NUM not in", values, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumBetween(String value1, String value2) {
            addCriterion("RES_NUM between", value1, value2, "resNum");
            return (Criteria) this;
        }

        public Criteria andResNumNotBetween(String value1, String value2) {
            addCriterion("RES_NUM not between", value1, value2, "resNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumIsNull() {
            addCriterion("PHONE_NUM is null");
            return (Criteria) this;
        }

        public Criteria andPhoneNumIsNotNull() {
            addCriterion("PHONE_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andPhoneNumEqualTo(String value) {
            addCriterion("PHONE_NUM =", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumNotEqualTo(String value) {
            addCriterion("PHONE_NUM <>", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumGreaterThan(String value) {
            addCriterion("PHONE_NUM >", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumGreaterThanOrEqualTo(String value) {
            addCriterion("PHONE_NUM >=", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumLessThan(String value) {
            addCriterion("PHONE_NUM <", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumLessThanOrEqualTo(String value) {
            addCriterion("PHONE_NUM <=", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumLike(String value) {
            addCriterion("PHONE_NUM like", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumNotLike(String value) {
            addCriterion("PHONE_NUM not like", value, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumIn(List<String> values) {
            addCriterion("PHONE_NUM in", values, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumNotIn(List<String> values) {
            addCriterion("PHONE_NUM not in", values, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumBetween(String value1, String value2) {
            addCriterion("PHONE_NUM between", value1, value2, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andPhoneNumNotBetween(String value1, String value2) {
            addCriterion("PHONE_NUM not between", value1, value2, "phoneNum");
            return (Criteria) this;
        }

        public Criteria andStaPositionIsNull() {
            addCriterion("STA_POSITION is null");
            return (Criteria) this;
        }

        public Criteria andStaPositionIsNotNull() {
            addCriterion("STA_POSITION is not null");
            return (Criteria) this;
        }

        public Criteria andStaPositionEqualTo(String value) {
            addCriterion("STA_POSITION =", value, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionNotEqualTo(String value) {
            addCriterion("STA_POSITION <>", value, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionGreaterThan(String value) {
            addCriterion("STA_POSITION >", value, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionGreaterThanOrEqualTo(String value) {
            addCriterion("STA_POSITION >=", value, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionLessThan(String value) {
            addCriterion("STA_POSITION <", value, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionLessThanOrEqualTo(String value) {
            addCriterion("STA_POSITION <=", value, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionLike(String value) {
            addCriterion("STA_POSITION like", value, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionNotLike(String value) {
            addCriterion("STA_POSITION not like", value, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionIn(List<String> values) {
            addCriterion("STA_POSITION in", values, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionNotIn(List<String> values) {
            addCriterion("STA_POSITION not in", values, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionBetween(String value1, String value2) {
            addCriterion("STA_POSITION between", value1, value2, "staPosition");
            return (Criteria) this;
        }

        public Criteria andStaPositionNotBetween(String value1, String value2) {
            addCriterion("STA_POSITION not between", value1, value2, "staPosition");
            return (Criteria) this;
        }

        public Criteria andDepartmentIsNull() {
            addCriterion("DEPARTMENT is null");
            return (Criteria) this;
        }

        public Criteria andDepartmentIsNotNull() {
            addCriterion("DEPARTMENT is not null");
            return (Criteria) this;
        }

        public Criteria andDepartmentEqualTo(String value) {
            addCriterion("DEPARTMENT =", value, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentNotEqualTo(String value) {
            addCriterion("DEPARTMENT <>", value, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentGreaterThan(String value) {
            addCriterion("DEPARTMENT >", value, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentGreaterThanOrEqualTo(String value) {
            addCriterion("DEPARTMENT >=", value, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentLessThan(String value) {
            addCriterion("DEPARTMENT <", value, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentLessThanOrEqualTo(String value) {
            addCriterion("DEPARTMENT <=", value, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentLike(String value) {
            addCriterion("DEPARTMENT like", value, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentNotLike(String value) {
            addCriterion("DEPARTMENT not like", value, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentIn(List<String> values) {
            addCriterion("DEPARTMENT in", values, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentNotIn(List<String> values) {
            addCriterion("DEPARTMENT not in", values, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentBetween(String value1, String value2) {
            addCriterion("DEPARTMENT between", value1, value2, "department");
            return (Criteria) this;
        }

        public Criteria andDepartmentNotBetween(String value1, String value2) {
            addCriterion("DEPARTMENT not between", value1, value2, "department");
            return (Criteria) this;
        }

        public Criteria andProNumIsNull() {
            addCriterion("PRO_NUM is null");
            return (Criteria) this;
        }

        public Criteria andProNumIsNotNull() {
            addCriterion("PRO_NUM is not null");
            return (Criteria) this;
        }

        public Criteria andProNumEqualTo(String value) {
            addCriterion("PRO_NUM =", value, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumNotEqualTo(String value) {
            addCriterion("PRO_NUM <>", value, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumGreaterThan(String value) {
            addCriterion("PRO_NUM >", value, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumGreaterThanOrEqualTo(String value) {
            addCriterion("PRO_NUM >=", value, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumLessThan(String value) {
            addCriterion("PRO_NUM <", value, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumLessThanOrEqualTo(String value) {
            addCriterion("PRO_NUM <=", value, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumLike(String value) {
            addCriterion("PRO_NUM like", value, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumNotLike(String value) {
            addCriterion("PRO_NUM not like", value, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumIn(List<String> values) {
            addCriterion("PRO_NUM in", values, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumNotIn(List<String> values) {
            addCriterion("PRO_NUM not in", values, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumBetween(String value1, String value2) {
            addCriterion("PRO_NUM between", value1, value2, "proNum");
            return (Criteria) this;
        }

        public Criteria andProNumNotBetween(String value1, String value2) {
            addCriterion("PRO_NUM not between", value1, value2, "proNum");
            return (Criteria) this;
        }

        public Criteria andGroupIsNull() {
            addCriterion("GROUP is null");
            return (Criteria) this;
        }

        public Criteria andGroupIsNotNull() {
            addCriterion("GROUP is not null");
            return (Criteria) this;
        }

        public Criteria andGroupEqualTo(String value) {
            addCriterion("GROUP =", value, "group");
            return (Criteria) this;
        }

        public Criteria andGroupNotEqualTo(String value) {
            addCriterion("GROUP <>", value, "group");
            return (Criteria) this;
        }

        public Criteria andGroupGreaterThan(String value) {
            addCriterion("GROUP >", value, "group");
            return (Criteria) this;
        }

        public Criteria andGroupGreaterThanOrEqualTo(String value) {
            addCriterion("GROUP >=", value, "group");
            return (Criteria) this;
        }

        public Criteria andGroupLessThan(String value) {
            addCriterion("GROUP <", value, "group");
            return (Criteria) this;
        }

        public Criteria andGroupLessThanOrEqualTo(String value) {
            addCriterion("GROUP <=", value, "group");
            return (Criteria) this;
        }

        public Criteria andGroupLike(String value) {
            addCriterion("GROUP like", value, "group");
            return (Criteria) this;
        }

        public Criteria andGroupNotLike(String value) {
            addCriterion("GROUP not like", value, "group");
            return (Criteria) this;
        }

        public Criteria andGroupIn(List<String> values) {
            addCriterion("GROUP in", values, "group");
            return (Criteria) this;
        }

        public Criteria andGroupNotIn(List<String> values) {
            addCriterion("GROUP not in", values, "group");
            return (Criteria) this;
        }

        public Criteria andGroupBetween(String value1, String value2) {
            addCriterion("GROUP between", value1, value2, "group");
            return (Criteria) this;
        }

        public Criteria andGroupNotBetween(String value1, String value2) {
            addCriterion("GROUP not between", value1, value2, "group");
            return (Criteria) this;
        }

        public Criteria andCommandoLogIsNull() {
            addCriterion("COMMANDO_LOG is null");
            return (Criteria) this;
        }

        public Criteria andCommandoLogIsNotNull() {
            addCriterion("COMMANDO_LOG is not null");
            return (Criteria) this;
        }

        public Criteria andCommandoLogEqualTo(String value) {
            addCriterion("COMMANDO_LOG =", value, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogNotEqualTo(String value) {
            addCriterion("COMMANDO_LOG <>", value, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogGreaterThan(String value) {
            addCriterion("COMMANDO_LOG >", value, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogGreaterThanOrEqualTo(String value) {
            addCriterion("COMMANDO_LOG >=", value, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogLessThan(String value) {
            addCriterion("COMMANDO_LOG <", value, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogLessThanOrEqualTo(String value) {
            addCriterion("COMMANDO_LOG <=", value, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogLike(String value) {
            addCriterion("COMMANDO_LOG like", value, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogNotLike(String value) {
            addCriterion("COMMANDO_LOG not like", value, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogIn(List<String> values) {
            addCriterion("COMMANDO_LOG in", values, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogNotIn(List<String> values) {
            addCriterion("COMMANDO_LOG not in", values, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogBetween(String value1, String value2) {
            addCriterion("COMMANDO_LOG between", value1, value2, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andCommandoLogNotBetween(String value1, String value2) {
            addCriterion("COMMANDO_LOG not between", value1, value2, "commandoLog");
            return (Criteria) this;
        }

        public Criteria andEmpStateIsNull() {
            addCriterion("EMP_STATE is null");
            return (Criteria) this;
        }

        public Criteria andEmpStateIsNotNull() {
            addCriterion("EMP_STATE is not null");
            return (Criteria) this;
        }

        public Criteria andEmpStateEqualTo(String value) {
            addCriterion("EMP_STATE =", value, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateNotEqualTo(String value) {
            addCriterion("EMP_STATE <>", value, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateGreaterThan(String value) {
            addCriterion("EMP_STATE >", value, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateGreaterThanOrEqualTo(String value) {
            addCriterion("EMP_STATE >=", value, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateLessThan(String value) {
            addCriterion("EMP_STATE <", value, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateLessThanOrEqualTo(String value) {
            addCriterion("EMP_STATE <=", value, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateLike(String value) {
            addCriterion("EMP_STATE like", value, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateNotLike(String value) {
            addCriterion("EMP_STATE not like", value, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateIn(List<String> values) {
            addCriterion("EMP_STATE in", values, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateNotIn(List<String> values) {
            addCriterion("EMP_STATE not in", values, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateBetween(String value1, String value2) {
            addCriterion("EMP_STATE between", value1, value2, "empState");
            return (Criteria) this;
        }

        public Criteria andEmpStateNotBetween(String value1, String value2) {
            addCriterion("EMP_STATE not between", value1, value2, "empState");
            return (Criteria) this;
        }

        public Criteria andHolidayIsNull() {
            addCriterion("HOLIDAY is null");
            return (Criteria) this;
        }

        public Criteria andHolidayIsNotNull() {
            addCriterion("HOLIDAY is not null");
            return (Criteria) this;
        }

        public Criteria andHolidayEqualTo(Long value) {
            addCriterion("HOLIDAY =", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayNotEqualTo(Long value) {
            addCriterion("HOLIDAY <>", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayGreaterThan(Long value) {
            addCriterion("HOLIDAY >", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayGreaterThanOrEqualTo(Long value) {
            addCriterion("HOLIDAY >=", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayLessThan(Long value) {
            addCriterion("HOLIDAY <", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayLessThanOrEqualTo(Long value) {
            addCriterion("HOLIDAY <=", value, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayIn(List<Long> values) {
            addCriterion("HOLIDAY in", values, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayNotIn(List<Long> values) {
            addCriterion("HOLIDAY not in", values, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayBetween(Long value1, Long value2) {
            addCriterion("HOLIDAY between", value1, value2, "holiday");
            return (Criteria) this;
        }

        public Criteria andHolidayNotBetween(Long value1, Long value2) {
            addCriterion("HOLIDAY not between", value1, value2, "holiday");
            return (Criteria) this;
        }

        public Criteria andCrtTimeIsNull() {
            addCriterion("CRT_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCrtTimeIsNotNull() {
            addCriterion("CRT_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCrtTimeEqualTo(Date value) {
            addCriterion("CRT_TIME =", value, "crtTime");
            return (Criteria) this;
        }

        public Criteria andCrtTimeNotEqualTo(Date value) {
            addCriterion("CRT_TIME <>", value, "crtTime");
            return (Criteria) this;
        }

        public Criteria andCrtTimeGreaterThan(Date value) {
            addCriterion("CRT_TIME >", value, "crtTime");
            return (Criteria) this;
        }

        public Criteria andCrtTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CRT_TIME >=", value, "crtTime");
            return (Criteria) this;
        }

        public Criteria andCrtTimeLessThan(Date value) {
            addCriterion("CRT_TIME <", value, "crtTime");
            return (Criteria) this;
        }

        public Criteria andCrtTimeLessThanOrEqualTo(Date value) {
            addCriterion("CRT_TIME <=", value, "crtTime");
            return (Criteria) this;
        }

        public Criteria andCrtTimeIn(List<Date> values) {
            addCriterion("CRT_TIME in", values, "crtTime");
            return (Criteria) this;
        }

        public Criteria andCrtTimeNotIn(List<Date> values) {
            addCriterion("CRT_TIME not in", values, "crtTime");
            return (Criteria) this;
        }

        public Criteria andCrtTimeBetween(Date value1, Date value2) {
            addCriterion("CRT_TIME between", value1, value2, "crtTime");
            return (Criteria) this;
        }

        public Criteria andCrtTimeNotBetween(Date value1, Date value2) {
            addCriterion("CRT_TIME not between", value1, value2, "crtTime");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("REMARK is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("REMARK is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("REMARK =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("REMARK <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("REMARK >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("REMARK >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("REMARK <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("REMARK <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("REMARK like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("REMARK not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("REMARK in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("REMARK not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("REMARK between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("REMARK not between", value1, value2, "remark");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}