package com.cmos.mmp.dao.phonecard;

import com.cmos.mmp.beans.phonecard.employee;
import com.cmos.mmp.beans.phonecard.employeeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface employeeMapper {
    long countByExample(employeeExample example);

    int deleteByExample(employeeExample example);

    int deleteByPrimaryKey(String jobId);

    int insert(employee record);

    int insertSelective(employee record);

    List<employee> selectByExample(employeeExample example);

    employee selectByPrimaryKey(String jobId);

    int updateByExampleSelective(@Param("record") employee record, @Param("example") employeeExample example);

    int updateByExample(@Param("record") employee record, @Param("example") employeeExample example);

    int updateByPrimaryKeySelective(employee record);

    int updateByPrimaryKey(employee record);
}