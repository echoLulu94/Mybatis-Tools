package com.cmos.qrcode.beans.distribution;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class QCAgentGoodsExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public QCAgentGoodsExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(String value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(String value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(String value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(String value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(String value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(String value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLike(String value) {
            addCriterion("id like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotLike(String value) {
            addCriterion("id not like", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<String> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<String> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(String value1, String value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(String value1, String value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andOriginIsNull() {
            addCriterion("origin is null");
            return (Criteria) this;
        }

        public Criteria andOriginIsNotNull() {
            addCriterion("origin is not null");
            return (Criteria) this;
        }

        public Criteria andOriginEqualTo(String value) {
            addCriterion("origin =", value, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginNotEqualTo(String value) {
            addCriterion("origin <>", value, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginGreaterThan(String value) {
            addCriterion("origin >", value, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginGreaterThanOrEqualTo(String value) {
            addCriterion("origin >=", value, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginLessThan(String value) {
            addCriterion("origin <", value, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginLessThanOrEqualTo(String value) {
            addCriterion("origin <=", value, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginLike(String value) {
            addCriterion("origin like", value, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginNotLike(String value) {
            addCriterion("origin not like", value, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginIn(List<String> values) {
            addCriterion("origin in", values, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginNotIn(List<String> values) {
            addCriterion("origin not in", values, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginBetween(String value1, String value2) {
            addCriterion("origin between", value1, value2, "origin");
            return (Criteria) this;
        }

        public Criteria andOriginNotBetween(String value1, String value2) {
            addCriterion("origin not between", value1, value2, "origin");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeIsNull() {
            addCriterion("sales_man_type is null");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeIsNotNull() {
            addCriterion("sales_man_type is not null");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeEqualTo(String value) {
            addCriterion("sales_man_type =", value, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeNotEqualTo(String value) {
            addCriterion("sales_man_type <>", value, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeGreaterThan(String value) {
            addCriterion("sales_man_type >", value, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeGreaterThanOrEqualTo(String value) {
            addCriterion("sales_man_type >=", value, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeLessThan(String value) {
            addCriterion("sales_man_type <", value, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeLessThanOrEqualTo(String value) {
            addCriterion("sales_man_type <=", value, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeLike(String value) {
            addCriterion("sales_man_type like", value, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeNotLike(String value) {
            addCriterion("sales_man_type not like", value, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeIn(List<String> values) {
            addCriterion("sales_man_type in", values, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeNotIn(List<String> values) {
            addCriterion("sales_man_type not in", values, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeBetween(String value1, String value2) {
            addCriterion("sales_man_type between", value1, value2, "salesManType");
            return (Criteria) this;
        }

        public Criteria andSalesManTypeNotBetween(String value1, String value2) {
            addCriterion("sales_man_type not between", value1, value2, "salesManType");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNull() {
            addCriterion("order_id is null");
            return (Criteria) this;
        }

        public Criteria andOrderIdIsNotNull() {
            addCriterion("order_id is not null");
            return (Criteria) this;
        }

        public Criteria andOrderIdEqualTo(String value) {
            addCriterion("order_id =", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotEqualTo(String value) {
            addCriterion("order_id <>", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThan(String value) {
            addCriterion("order_id >", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdGreaterThanOrEqualTo(String value) {
            addCriterion("order_id >=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThan(String value) {
            addCriterion("order_id <", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLessThanOrEqualTo(String value) {
            addCriterion("order_id <=", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdLike(String value) {
            addCriterion("order_id like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotLike(String value) {
            addCriterion("order_id not like", value, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdIn(List<String> values) {
            addCriterion("order_id in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotIn(List<String> values) {
            addCriterion("order_id not in", values, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdBetween(String value1, String value2) {
            addCriterion("order_id between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderIdNotBetween(String value1, String value2) {
            addCriterion("order_id not between", value1, value2, "orderId");
            return (Criteria) this;
        }

        public Criteria andOrderNumberIsNull() {
            addCriterion("order_number is null");
            return (Criteria) this;
        }

        public Criteria andOrderNumberIsNotNull() {
            addCriterion("order_number is not null");
            return (Criteria) this;
        }

        public Criteria andOrderNumberEqualTo(String value) {
            addCriterion("order_number =", value, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberNotEqualTo(String value) {
            addCriterion("order_number <>", value, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberGreaterThan(String value) {
            addCriterion("order_number >", value, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberGreaterThanOrEqualTo(String value) {
            addCriterion("order_number >=", value, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberLessThan(String value) {
            addCriterion("order_number <", value, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberLessThanOrEqualTo(String value) {
            addCriterion("order_number <=", value, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberLike(String value) {
            addCriterion("order_number like", value, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberNotLike(String value) {
            addCriterion("order_number not like", value, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberIn(List<String> values) {
            addCriterion("order_number in", values, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberNotIn(List<String> values) {
            addCriterion("order_number not in", values, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberBetween(String value1, String value2) {
            addCriterion("order_number between", value1, value2, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andOrderNumberNotBetween(String value1, String value2) {
            addCriterion("order_number not between", value1, value2, "orderNumber");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoIsNull() {
            addCriterion("sales_man_phone_no is null");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoIsNotNull() {
            addCriterion("sales_man_phone_no is not null");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoEqualTo(String value) {
            addCriterion("sales_man_phone_no =", value, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoNotEqualTo(String value) {
            addCriterion("sales_man_phone_no <>", value, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoGreaterThan(String value) {
            addCriterion("sales_man_phone_no >", value, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoGreaterThanOrEqualTo(String value) {
            addCriterion("sales_man_phone_no >=", value, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoLessThan(String value) {
            addCriterion("sales_man_phone_no <", value, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoLessThanOrEqualTo(String value) {
            addCriterion("sales_man_phone_no <=", value, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoLike(String value) {
            addCriterion("sales_man_phone_no like", value, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoNotLike(String value) {
            addCriterion("sales_man_phone_no not like", value, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoIn(List<String> values) {
            addCriterion("sales_man_phone_no in", values, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoNotIn(List<String> values) {
            addCriterion("sales_man_phone_no not in", values, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoBetween(String value1, String value2) {
            addCriterion("sales_man_phone_no between", value1, value2, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andSalesManPhoneNoNotBetween(String value1, String value2) {
            addCriterion("sales_man_phone_no not between", value1, value2, "salesManPhoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoIsNull() {
            addCriterion("phone_no is null");
            return (Criteria) this;
        }

        public Criteria andPhoneNoIsNotNull() {
            addCriterion("phone_no is not null");
            return (Criteria) this;
        }

        public Criteria andPhoneNoEqualTo(String value) {
            addCriterion("phone_no =", value, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoNotEqualTo(String value) {
            addCriterion("phone_no <>", value, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoGreaterThan(String value) {
            addCriterion("phone_no >", value, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoGreaterThanOrEqualTo(String value) {
            addCriterion("phone_no >=", value, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoLessThan(String value) {
            addCriterion("phone_no <", value, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoLessThanOrEqualTo(String value) {
            addCriterion("phone_no <=", value, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoLike(String value) {
            addCriterion("phone_no like", value, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoNotLike(String value) {
            addCriterion("phone_no not like", value, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoIn(List<String> values) {
            addCriterion("phone_no in", values, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoNotIn(List<String> values) {
            addCriterion("phone_no not in", values, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoBetween(String value1, String value2) {
            addCriterion("phone_no between", value1, value2, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andPhoneNoNotBetween(String value1, String value2) {
            addCriterion("phone_no not between", value1, value2, "phoneNo");
            return (Criteria) this;
        }

        public Criteria andGoodsNameIsNull() {
            addCriterion("goods_name is null");
            return (Criteria) this;
        }

        public Criteria andGoodsNameIsNotNull() {
            addCriterion("goods_name is not null");
            return (Criteria) this;
        }

        public Criteria andGoodsNameEqualTo(String value) {
            addCriterion("goods_name =", value, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameNotEqualTo(String value) {
            addCriterion("goods_name <>", value, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameGreaterThan(String value) {
            addCriterion("goods_name >", value, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameGreaterThanOrEqualTo(String value) {
            addCriterion("goods_name >=", value, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameLessThan(String value) {
            addCriterion("goods_name <", value, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameLessThanOrEqualTo(String value) {
            addCriterion("goods_name <=", value, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameLike(String value) {
            addCriterion("goods_name like", value, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameNotLike(String value) {
            addCriterion("goods_name not like", value, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameIn(List<String> values) {
            addCriterion("goods_name in", values, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameNotIn(List<String> values) {
            addCriterion("goods_name not in", values, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameBetween(String value1, String value2) {
            addCriterion("goods_name between", value1, value2, "goodsName");
            return (Criteria) this;
        }

        public Criteria andGoodsNameNotBetween(String value1, String value2) {
            addCriterion("goods_name not between", value1, value2, "goodsName");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceIsNull() {
            addCriterion("apply_balance is null");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceIsNotNull() {
            addCriterion("apply_balance is not null");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceEqualTo(Long value) {
            addCriterion("apply_balance =", value, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceNotEqualTo(Long value) {
            addCriterion("apply_balance <>", value, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceGreaterThan(Long value) {
            addCriterion("apply_balance >", value, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceGreaterThanOrEqualTo(Long value) {
            addCriterion("apply_balance >=", value, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceLessThan(Long value) {
            addCriterion("apply_balance <", value, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceLessThanOrEqualTo(Long value) {
            addCriterion("apply_balance <=", value, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceIn(List<Long> values) {
            addCriterion("apply_balance in", values, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceNotIn(List<Long> values) {
            addCriterion("apply_balance not in", values, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceBetween(Long value1, Long value2) {
            addCriterion("apply_balance between", value1, value2, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andApplyBalanceNotBetween(Long value1, Long value2) {
            addCriterion("apply_balance not between", value1, value2, "applyBalance");
            return (Criteria) this;
        }

        public Criteria andSalesManIdIsNull() {
            addCriterion("sales_man_id is null");
            return (Criteria) this;
        }

        public Criteria andSalesManIdIsNotNull() {
            addCriterion("sales_man_id is not null");
            return (Criteria) this;
        }

        public Criteria andSalesManIdEqualTo(String value) {
            addCriterion("sales_man_id =", value, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdNotEqualTo(String value) {
            addCriterion("sales_man_id <>", value, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdGreaterThan(String value) {
            addCriterion("sales_man_id >", value, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdGreaterThanOrEqualTo(String value) {
            addCriterion("sales_man_id >=", value, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdLessThan(String value) {
            addCriterion("sales_man_id <", value, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdLessThanOrEqualTo(String value) {
            addCriterion("sales_man_id <=", value, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdLike(String value) {
            addCriterion("sales_man_id like", value, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdNotLike(String value) {
            addCriterion("sales_man_id not like", value, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdIn(List<String> values) {
            addCriterion("sales_man_id in", values, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdNotIn(List<String> values) {
            addCriterion("sales_man_id not in", values, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdBetween(String value1, String value2) {
            addCriterion("sales_man_id between", value1, value2, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManIdNotBetween(String value1, String value2) {
            addCriterion("sales_man_id not between", value1, value2, "salesManId");
            return (Criteria) this;
        }

        public Criteria andSalesManNameIsNull() {
            addCriterion("sales_man_name is null");
            return (Criteria) this;
        }

        public Criteria andSalesManNameIsNotNull() {
            addCriterion("sales_man_name is not null");
            return (Criteria) this;
        }

        public Criteria andSalesManNameEqualTo(String value) {
            addCriterion("sales_man_name =", value, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameNotEqualTo(String value) {
            addCriterion("sales_man_name <>", value, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameGreaterThan(String value) {
            addCriterion("sales_man_name >", value, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameGreaterThanOrEqualTo(String value) {
            addCriterion("sales_man_name >=", value, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameLessThan(String value) {
            addCriterion("sales_man_name <", value, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameLessThanOrEqualTo(String value) {
            addCriterion("sales_man_name <=", value, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameLike(String value) {
            addCriterion("sales_man_name like", value, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameNotLike(String value) {
            addCriterion("sales_man_name not like", value, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameIn(List<String> values) {
            addCriterion("sales_man_name in", values, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameNotIn(List<String> values) {
            addCriterion("sales_man_name not in", values, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameBetween(String value1, String value2) {
            addCriterion("sales_man_name between", value1, value2, "salesManName");
            return (Criteria) this;
        }

        public Criteria andSalesManNameNotBetween(String value1, String value2) {
            addCriterion("sales_man_name not between", value1, value2, "salesManName");
            return (Criteria) this;
        }

        public Criteria andAgentIdIsNull() {
            addCriterion("agent_id is null");
            return (Criteria) this;
        }

        public Criteria andAgentIdIsNotNull() {
            addCriterion("agent_id is not null");
            return (Criteria) this;
        }

        public Criteria andAgentIdEqualTo(String value) {
            addCriterion("agent_id =", value, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdNotEqualTo(String value) {
            addCriterion("agent_id <>", value, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdGreaterThan(String value) {
            addCriterion("agent_id >", value, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdGreaterThanOrEqualTo(String value) {
            addCriterion("agent_id >=", value, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdLessThan(String value) {
            addCriterion("agent_id <", value, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdLessThanOrEqualTo(String value) {
            addCriterion("agent_id <=", value, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdLike(String value) {
            addCriterion("agent_id like", value, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdNotLike(String value) {
            addCriterion("agent_id not like", value, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdIn(List<String> values) {
            addCriterion("agent_id in", values, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdNotIn(List<String> values) {
            addCriterion("agent_id not in", values, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdBetween(String value1, String value2) {
            addCriterion("agent_id between", value1, value2, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentIdNotBetween(String value1, String value2) {
            addCriterion("agent_id not between", value1, value2, "agentId");
            return (Criteria) this;
        }

        public Criteria andAgentNameIsNull() {
            addCriterion("agent_name is null");
            return (Criteria) this;
        }

        public Criteria andAgentNameIsNotNull() {
            addCriterion("agent_name is not null");
            return (Criteria) this;
        }

        public Criteria andAgentNameEqualTo(String value) {
            addCriterion("agent_name =", value, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameNotEqualTo(String value) {
            addCriterion("agent_name <>", value, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameGreaterThan(String value) {
            addCriterion("agent_name >", value, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameGreaterThanOrEqualTo(String value) {
            addCriterion("agent_name >=", value, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameLessThan(String value) {
            addCriterion("agent_name <", value, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameLessThanOrEqualTo(String value) {
            addCriterion("agent_name <=", value, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameLike(String value) {
            addCriterion("agent_name like", value, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameNotLike(String value) {
            addCriterion("agent_name not like", value, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameIn(List<String> values) {
            addCriterion("agent_name in", values, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameNotIn(List<String> values) {
            addCriterion("agent_name not in", values, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameBetween(String value1, String value2) {
            addCriterion("agent_name between", value1, value2, "agentName");
            return (Criteria) this;
        }

        public Criteria andAgentNameNotBetween(String value1, String value2) {
            addCriterion("agent_name not between", value1, value2, "agentName");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoIsNull() {
            addCriterion("goods_info is null");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoIsNotNull() {
            addCriterion("goods_info is not null");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoEqualTo(String value) {
            addCriterion("goods_info =", value, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoNotEqualTo(String value) {
            addCriterion("goods_info <>", value, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoGreaterThan(String value) {
            addCriterion("goods_info >", value, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoGreaterThanOrEqualTo(String value) {
            addCriterion("goods_info >=", value, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoLessThan(String value) {
            addCriterion("goods_info <", value, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoLessThanOrEqualTo(String value) {
            addCriterion("goods_info <=", value, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoLike(String value) {
            addCriterion("goods_info like", value, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoNotLike(String value) {
            addCriterion("goods_info not like", value, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoIn(List<String> values) {
            addCriterion("goods_info in", values, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoNotIn(List<String> values) {
            addCriterion("goods_info not in", values, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoBetween(String value1, String value2) {
            addCriterion("goods_info between", value1, value2, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andGoodsInfoNotBetween(String value1, String value2) {
            addCriterion("goods_info not between", value1, value2, "goodsInfo");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateIsNull() {
            addCriterion("settle_accounts_state is null");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateIsNotNull() {
            addCriterion("settle_accounts_state is not null");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateEqualTo(String value) {
            addCriterion("settle_accounts_state =", value, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateNotEqualTo(String value) {
            addCriterion("settle_accounts_state <>", value, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateGreaterThan(String value) {
            addCriterion("settle_accounts_state >", value, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateGreaterThanOrEqualTo(String value) {
            addCriterion("settle_accounts_state >=", value, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateLessThan(String value) {
            addCriterion("settle_accounts_state <", value, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateLessThanOrEqualTo(String value) {
            addCriterion("settle_accounts_state <=", value, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateLike(String value) {
            addCriterion("settle_accounts_state like", value, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateNotLike(String value) {
            addCriterion("settle_accounts_state not like", value, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateIn(List<String> values) {
            addCriterion("settle_accounts_state in", values, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateNotIn(List<String> values) {
            addCriterion("settle_accounts_state not in", values, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateBetween(String value1, String value2) {
            addCriterion("settle_accounts_state between", value1, value2, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andSettleAccountsStateNotBetween(String value1, String value2) {
            addCriterion("settle_accounts_state not between", value1, value2, "settleAccountsState");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidIsNull() {
            addCriterion("crmpf_pub_info_staffId is null");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidIsNotNull() {
            addCriterion("crmpf_pub_info_staffId is not null");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidEqualTo(String value) {
            addCriterion("crmpf_pub_info_staffId =", value, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidNotEqualTo(String value) {
            addCriterion("crmpf_pub_info_staffId <>", value, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidGreaterThan(String value) {
            addCriterion("crmpf_pub_info_staffId >", value, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidGreaterThanOrEqualTo(String value) {
            addCriterion("crmpf_pub_info_staffId >=", value, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidLessThan(String value) {
            addCriterion("crmpf_pub_info_staffId <", value, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidLessThanOrEqualTo(String value) {
            addCriterion("crmpf_pub_info_staffId <=", value, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidLike(String value) {
            addCriterion("crmpf_pub_info_staffId like", value, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidNotLike(String value) {
            addCriterion("crmpf_pub_info_staffId not like", value, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidIn(List<String> values) {
            addCriterion("crmpf_pub_info_staffId in", values, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidNotIn(List<String> values) {
            addCriterion("crmpf_pub_info_staffId not in", values, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidBetween(String value1, String value2) {
            addCriterion("crmpf_pub_info_staffId between", value1, value2, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoStaffidNotBetween(String value1, String value2) {
            addCriterion("crmpf_pub_info_staffId not between", value1, value2, "crmpfPubInfoStaffid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidIsNull() {
            addCriterion("crmpf_pub_info_orgId is null");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidIsNotNull() {
            addCriterion("crmpf_pub_info_orgId is not null");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidEqualTo(String value) {
            addCriterion("crmpf_pub_info_orgId =", value, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidNotEqualTo(String value) {
            addCriterion("crmpf_pub_info_orgId <>", value, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidGreaterThan(String value) {
            addCriterion("crmpf_pub_info_orgId >", value, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidGreaterThanOrEqualTo(String value) {
            addCriterion("crmpf_pub_info_orgId >=", value, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidLessThan(String value) {
            addCriterion("crmpf_pub_info_orgId <", value, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidLessThanOrEqualTo(String value) {
            addCriterion("crmpf_pub_info_orgId <=", value, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidLike(String value) {
            addCriterion("crmpf_pub_info_orgId like", value, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidNotLike(String value) {
            addCriterion("crmpf_pub_info_orgId not like", value, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidIn(List<String> values) {
            addCriterion("crmpf_pub_info_orgId in", values, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidNotIn(List<String> values) {
            addCriterion("crmpf_pub_info_orgId not in", values, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidBetween(String value1, String value2) {
            addCriterion("crmpf_pub_info_orgId between", value1, value2, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoOrgidNotBetween(String value1, String value2) {
            addCriterion("crmpf_pub_info_orgId not between", value1, value2, "crmpfPubInfoOrgid");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeIsNull() {
            addCriterion("crmpf_pub_info_city_code is null");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeIsNotNull() {
            addCriterion("crmpf_pub_info_city_code is not null");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeEqualTo(String value) {
            addCriterion("crmpf_pub_info_city_code =", value, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeNotEqualTo(String value) {
            addCriterion("crmpf_pub_info_city_code <>", value, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeGreaterThan(String value) {
            addCriterion("crmpf_pub_info_city_code >", value, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeGreaterThanOrEqualTo(String value) {
            addCriterion("crmpf_pub_info_city_code >=", value, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeLessThan(String value) {
            addCriterion("crmpf_pub_info_city_code <", value, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeLessThanOrEqualTo(String value) {
            addCriterion("crmpf_pub_info_city_code <=", value, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeLike(String value) {
            addCriterion("crmpf_pub_info_city_code like", value, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeNotLike(String value) {
            addCriterion("crmpf_pub_info_city_code not like", value, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeIn(List<String> values) {
            addCriterion("crmpf_pub_info_city_code in", values, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeNotIn(List<String> values) {
            addCriterion("crmpf_pub_info_city_code not in", values, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeBetween(String value1, String value2) {
            addCriterion("crmpf_pub_info_city_code between", value1, value2, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCityCodeNotBetween(String value1, String value2) {
            addCriterion("crmpf_pub_info_city_code not between", value1, value2, "crmpfPubInfoCityCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeIsNull() {
            addCriterion("crmpf_pub_info_country_code is null");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeIsNotNull() {
            addCriterion("crmpf_pub_info_country_code is not null");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeEqualTo(String value) {
            addCriterion("crmpf_pub_info_country_code =", value, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeNotEqualTo(String value) {
            addCriterion("crmpf_pub_info_country_code <>", value, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeGreaterThan(String value) {
            addCriterion("crmpf_pub_info_country_code >", value, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeGreaterThanOrEqualTo(String value) {
            addCriterion("crmpf_pub_info_country_code >=", value, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeLessThan(String value) {
            addCriterion("crmpf_pub_info_country_code <", value, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeLessThanOrEqualTo(String value) {
            addCriterion("crmpf_pub_info_country_code <=", value, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeLike(String value) {
            addCriterion("crmpf_pub_info_country_code like", value, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeNotLike(String value) {
            addCriterion("crmpf_pub_info_country_code not like", value, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeIn(List<String> values) {
            addCriterion("crmpf_pub_info_country_code in", values, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeNotIn(List<String> values) {
            addCriterion("crmpf_pub_info_country_code not in", values, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeBetween(String value1, String value2) {
            addCriterion("crmpf_pub_info_country_code between", value1, value2, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andCrmpfPubInfoCountryCodeNotBetween(String value1, String value2) {
            addCriterion("crmpf_pub_info_country_code not between", value1, value2, "crmpfPubInfoCountryCode");
            return (Criteria) this;
        }

        public Criteria andRemarksIsNull() {
            addCriterion("remarks is null");
            return (Criteria) this;
        }

        public Criteria andRemarksIsNotNull() {
            addCriterion("remarks is not null");
            return (Criteria) this;
        }

        public Criteria andRemarksEqualTo(String value) {
            addCriterion("remarks =", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksNotEqualTo(String value) {
            addCriterion("remarks <>", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksGreaterThan(String value) {
            addCriterion("remarks >", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksGreaterThanOrEqualTo(String value) {
            addCriterion("remarks >=", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksLessThan(String value) {
            addCriterion("remarks <", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksLessThanOrEqualTo(String value) {
            addCriterion("remarks <=", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksLike(String value) {
            addCriterion("remarks like", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksNotLike(String value) {
            addCriterion("remarks not like", value, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksIn(List<String> values) {
            addCriterion("remarks in", values, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksNotIn(List<String> values) {
            addCriterion("remarks not in", values, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksBetween(String value1, String value2) {
            addCriterion("remarks between", value1, value2, "remarks");
            return (Criteria) this;
        }

        public Criteria andRemarksNotBetween(String value1, String value2) {
            addCriterion("remarks not between", value1, value2, "remarks");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardIsNull() {
            addCriterion("online_reward is null");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardIsNotNull() {
            addCriterion("online_reward is not null");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardEqualTo(Long value) {
            addCriterion("online_reward =", value, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardNotEqualTo(Long value) {
            addCriterion("online_reward <>", value, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardGreaterThan(Long value) {
            addCriterion("online_reward >", value, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardGreaterThanOrEqualTo(Long value) {
            addCriterion("online_reward >=", value, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardLessThan(Long value) {
            addCriterion("online_reward <", value, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardLessThanOrEqualTo(Long value) {
            addCriterion("online_reward <=", value, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardIn(List<Long> values) {
            addCriterion("online_reward in", values, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardNotIn(List<Long> values) {
            addCriterion("online_reward not in", values, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardBetween(Long value1, Long value2) {
            addCriterion("online_reward between", value1, value2, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andOnlineRewardNotBetween(Long value1, Long value2) {
            addCriterion("online_reward not between", value1, value2, "onlineReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardIsNull() {
            addCriterion("agent_reward is null");
            return (Criteria) this;
        }

        public Criteria andAgentRewardIsNotNull() {
            addCriterion("agent_reward is not null");
            return (Criteria) this;
        }

        public Criteria andAgentRewardEqualTo(Long value) {
            addCriterion("agent_reward =", value, "agentReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardNotEqualTo(Long value) {
            addCriterion("agent_reward <>", value, "agentReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardGreaterThan(Long value) {
            addCriterion("agent_reward >", value, "agentReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardGreaterThanOrEqualTo(Long value) {
            addCriterion("agent_reward >=", value, "agentReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardLessThan(Long value) {
            addCriterion("agent_reward <", value, "agentReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardLessThanOrEqualTo(Long value) {
            addCriterion("agent_reward <=", value, "agentReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardIn(List<Long> values) {
            addCriterion("agent_reward in", values, "agentReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardNotIn(List<Long> values) {
            addCriterion("agent_reward not in", values, "agentReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardBetween(Long value1, Long value2) {
            addCriterion("agent_reward between", value1, value2, "agentReward");
            return (Criteria) this;
        }

        public Criteria andAgentRewardNotBetween(Long value1, Long value2) {
            addCriterion("agent_reward not between", value1, value2, "agentReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardIsNull() {
            addCriterion("sales_reward is null");
            return (Criteria) this;
        }

        public Criteria andSalesRewardIsNotNull() {
            addCriterion("sales_reward is not null");
            return (Criteria) this;
        }

        public Criteria andSalesRewardEqualTo(Long value) {
            addCriterion("sales_reward =", value, "salesReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardNotEqualTo(Long value) {
            addCriterion("sales_reward <>", value, "salesReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardGreaterThan(Long value) {
            addCriterion("sales_reward >", value, "salesReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardGreaterThanOrEqualTo(Long value) {
            addCriterion("sales_reward >=", value, "salesReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardLessThan(Long value) {
            addCriterion("sales_reward <", value, "salesReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardLessThanOrEqualTo(Long value) {
            addCriterion("sales_reward <=", value, "salesReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardIn(List<Long> values) {
            addCriterion("sales_reward in", values, "salesReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardNotIn(List<Long> values) {
            addCriterion("sales_reward not in", values, "salesReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardBetween(Long value1, Long value2) {
            addCriterion("sales_reward between", value1, value2, "salesReward");
            return (Criteria) this;
        }

        public Criteria andSalesRewardNotBetween(Long value1, Long value2) {
            addCriterion("sales_reward not between", value1, value2, "salesReward");
            return (Criteria) this;
        }

        public Criteria andIsbalanceIsNull() {
            addCriterion("isBalance is null");
            return (Criteria) this;
        }

        public Criteria andIsbalanceIsNotNull() {
            addCriterion("isBalance is not null");
            return (Criteria) this;
        }

        public Criteria andIsbalanceEqualTo(String value) {
            addCriterion("isBalance =", value, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceNotEqualTo(String value) {
            addCriterion("isBalance <>", value, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceGreaterThan(String value) {
            addCriterion("isBalance >", value, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceGreaterThanOrEqualTo(String value) {
            addCriterion("isBalance >=", value, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceLessThan(String value) {
            addCriterion("isBalance <", value, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceLessThanOrEqualTo(String value) {
            addCriterion("isBalance <=", value, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceLike(String value) {
            addCriterion("isBalance like", value, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceNotLike(String value) {
            addCriterion("isBalance not like", value, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceIn(List<String> values) {
            addCriterion("isBalance in", values, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceNotIn(List<String> values) {
            addCriterion("isBalance not in", values, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceBetween(String value1, String value2) {
            addCriterion("isBalance between", value1, value2, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIsbalanceNotBetween(String value1, String value2) {
            addCriterion("isBalance not between", value1, value2, "isbalance");
            return (Criteria) this;
        }

        public Criteria andIseffectiveIsNull() {
            addCriterion("isEffective is null");
            return (Criteria) this;
        }

        public Criteria andIseffectiveIsNotNull() {
            addCriterion("isEffective is not null");
            return (Criteria) this;
        }

        public Criteria andIseffectiveEqualTo(String value) {
            addCriterion("isEffective =", value, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveNotEqualTo(String value) {
            addCriterion("isEffective <>", value, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveGreaterThan(String value) {
            addCriterion("isEffective >", value, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveGreaterThanOrEqualTo(String value) {
            addCriterion("isEffective >=", value, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveLessThan(String value) {
            addCriterion("isEffective <", value, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveLessThanOrEqualTo(String value) {
            addCriterion("isEffective <=", value, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveLike(String value) {
            addCriterion("isEffective like", value, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveNotLike(String value) {
            addCriterion("isEffective not like", value, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveIn(List<String> values) {
            addCriterion("isEffective in", values, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveNotIn(List<String> values) {
            addCriterion("isEffective not in", values, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveBetween(String value1, String value2) {
            addCriterion("isEffective between", value1, value2, "iseffective");
            return (Criteria) this;
        }

        public Criteria andIseffectiveNotBetween(String value1, String value2) {
            addCriterion("isEffective not between", value1, value2, "iseffective");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeIsNull() {
            addCriterion("effective_time is null");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeIsNotNull() {
            addCriterion("effective_time is not null");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeEqualTo(Date value) {
            addCriterion("effective_time =", value, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeNotEqualTo(Date value) {
            addCriterion("effective_time <>", value, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeGreaterThan(Date value) {
            addCriterion("effective_time >", value, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("effective_time >=", value, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeLessThan(Date value) {
            addCriterion("effective_time <", value, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeLessThanOrEqualTo(Date value) {
            addCriterion("effective_time <=", value, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeIn(List<Date> values) {
            addCriterion("effective_time in", values, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeNotIn(List<Date> values) {
            addCriterion("effective_time not in", values, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeBetween(Date value1, Date value2) {
            addCriterion("effective_time between", value1, value2, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andEffectiveTimeNotBetween(Date value1, Date value2) {
            addCriterion("effective_time not between", value1, value2, "effectiveTime");
            return (Criteria) this;
        }

        public Criteria andStateIsNull() {
            addCriterion("state is null");
            return (Criteria) this;
        }

        public Criteria andStateIsNotNull() {
            addCriterion("state is not null");
            return (Criteria) this;
        }

        public Criteria andStateEqualTo(String value) {
            addCriterion("state =", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotEqualTo(String value) {
            addCriterion("state <>", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateGreaterThan(String value) {
            addCriterion("state >", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateGreaterThanOrEqualTo(String value) {
            addCriterion("state >=", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateLessThan(String value) {
            addCriterion("state <", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateLessThanOrEqualTo(String value) {
            addCriterion("state <=", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateLike(String value) {
            addCriterion("state like", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotLike(String value) {
            addCriterion("state not like", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateIn(List<String> values) {
            addCriterion("state in", values, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotIn(List<String> values) {
            addCriterion("state not in", values, "state");
            return (Criteria) this;
        }

        public Criteria andStateBetween(String value1, String value2) {
            addCriterion("state between", value1, value2, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotBetween(String value1, String value2) {
            addCriterion("state not between", value1, value2, "state");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}