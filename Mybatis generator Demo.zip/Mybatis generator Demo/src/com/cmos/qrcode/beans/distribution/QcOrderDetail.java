package com.cmos.qrcode.beans.distribution;

import java.util.Date;

public class QCOrderDetail {
    private String id;

    private String origin;

    private String salesManType;

    private Date createTime;

    private String orderId;

    private String orderNumber;

    private String salesManPhoneNo;

    private String phoneNo;

    private String goodsName;

    private Long applyBalance;

    private String salesManId;

    private String salesManName;

    private String agentId;

    private String agentName;

    private String goodsInfo;

    private String settleAccountsState;

    private String crmpfPubInfoStaffid;

    private String crmpfPubInfoOrgid;

    private String crmpfPubInfoCityCode;

    private String crmpfPubInfoCountryCode;

    private String remarks;

    private Long onlineReward;

    private Long agentReward;

    private Long salesReward;

    private String isbalance;

    private String iseffective;

    private Date effectiveTime;

    private String state;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin == null ? null : origin.trim();
    }

    public String getSalesManType() {
        return salesManType;
    }

    public void setSalesManType(String salesManType) {
        this.salesManType = salesManType == null ? null : salesManType.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber == null ? null : orderNumber.trim();
    }

    public String getSalesManPhoneNo() {
        return salesManPhoneNo;
    }

    public void setSalesManPhoneNo(String salesManPhoneNo) {
        this.salesManPhoneNo = salesManPhoneNo == null ? null : salesManPhoneNo.trim();
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo == null ? null : phoneNo.trim();
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName == null ? null : goodsName.trim();
    }

    public Long getApplyBalance() {
        return applyBalance;
    }

    public void setApplyBalance(Long applyBalance) {
        this.applyBalance = applyBalance;
    }

    public String getSalesManId() {
        return salesManId;
    }

    public void setSalesManId(String salesManId) {
        this.salesManId = salesManId == null ? null : salesManId.trim();
    }

    public String getSalesManName() {
        return salesManName;
    }

    public void setSalesManName(String salesManName) {
        this.salesManName = salesManName == null ? null : salesManName.trim();
    }

    public String getAgentId() {
        return agentId;
    }

    public void setAgentId(String agentId) {
        this.agentId = agentId == null ? null : agentId.trim();
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName == null ? null : agentName.trim();
    }

    public String getGoodsInfo() {
        return goodsInfo;
    }

    public void setGoodsInfo(String goodsInfo) {
        this.goodsInfo = goodsInfo == null ? null : goodsInfo.trim();
    }

    public String getSettleAccountsState() {
        return settleAccountsState;
    }

    public void setSettleAccountsState(String settleAccountsState) {
        this.settleAccountsState = settleAccountsState == null ? null : settleAccountsState.trim();
    }

    public String getCrmpfPubInfoStaffid() {
        return crmpfPubInfoStaffid;
    }

    public void setCrmpfPubInfoStaffid(String crmpfPubInfoStaffid) {
        this.crmpfPubInfoStaffid = crmpfPubInfoStaffid == null ? null : crmpfPubInfoStaffid.trim();
    }

    public String getCrmpfPubInfoOrgid() {
        return crmpfPubInfoOrgid;
    }

    public void setCrmpfPubInfoOrgid(String crmpfPubInfoOrgid) {
        this.crmpfPubInfoOrgid = crmpfPubInfoOrgid == null ? null : crmpfPubInfoOrgid.trim();
    }

    public String getCrmpfPubInfoCityCode() {
        return crmpfPubInfoCityCode;
    }

    public void setCrmpfPubInfoCityCode(String crmpfPubInfoCityCode) {
        this.crmpfPubInfoCityCode = crmpfPubInfoCityCode == null ? null : crmpfPubInfoCityCode.trim();
    }

    public String getCrmpfPubInfoCountryCode() {
        return crmpfPubInfoCountryCode;
    }

    public void setCrmpfPubInfoCountryCode(String crmpfPubInfoCountryCode) {
        this.crmpfPubInfoCountryCode = crmpfPubInfoCountryCode == null ? null : crmpfPubInfoCountryCode.trim();
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }

    public Long getOnlineReward() {
        return onlineReward;
    }

    public void setOnlineReward(Long onlineReward) {
        this.onlineReward = onlineReward;
    }

    public Long getAgentReward() {
        return agentReward;
    }

    public void setAgentReward(Long agentReward) {
        this.agentReward = agentReward;
    }

    public Long getSalesReward() {
        return salesReward;
    }

    public void setSalesReward(Long salesReward) {
        this.salesReward = salesReward;
    }

    public String getIsbalance() {
        return isbalance;
    }

    public void setIsbalance(String isbalance) {
        this.isbalance = isbalance == null ? null : isbalance.trim();
    }

    public String getIseffective() {
        return iseffective;
    }

    public void setIseffective(String iseffective) {
        this.iseffective = iseffective == null ? null : iseffective.trim();
    }

    public Date getEffectiveTime() {
        return effectiveTime;
    }

    public void setEffectiveTime(Date effectiveTime) {
        this.effectiveTime = effectiveTime;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }
}