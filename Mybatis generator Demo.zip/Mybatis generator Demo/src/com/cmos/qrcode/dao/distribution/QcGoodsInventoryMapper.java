package com.cmos.qrcode.dao.distribution;

import com.cmos.qrcode.beans.distribution.QcGoodsInventory;
import com.cmos.qrcode.beans.distribution.QcGoodsInventoryExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface QcGoodsInventoryMapper {
    long countByExample(QcGoodsInventoryExample example);

    int deleteByExample(QcGoodsInventoryExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(QcGoodsInventory record);

    int insertSelective(QcGoodsInventory record);

    List<QcGoodsInventory> selectByExample(QcGoodsInventoryExample example);

    QcGoodsInventory selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") QcGoodsInventory record, @Param("example") QcGoodsInventoryExample example);

    int updateByExample(@Param("record") QcGoodsInventory record, @Param("example") QcGoodsInventoryExample example);

    int updateByPrimaryKeySelective(QcGoodsInventory record);

    int updateByPrimaryKey(QcGoodsInventory record);
}