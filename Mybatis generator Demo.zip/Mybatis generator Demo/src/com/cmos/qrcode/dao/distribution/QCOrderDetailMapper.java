package com.cmos.qrcode.dao.distribution;

import com.cmos.qrcode.beans.distribution.QCOrderDetail;
import com.cmos.qrcode.beans.distribution.QCOrderDetailExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface QCOrderDetailMapper {
    long countByExample(QCOrderDetailExample example);

    int deleteByExample(QCOrderDetailExample example);

    int deleteByPrimaryKey(String id);

    int insert(QCOrderDetail record);

    int insertSelective(QCOrderDetail record);

    List<QCOrderDetail> selectByExample(QCOrderDetailExample example);

    QCOrderDetail selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") QCOrderDetail record, @Param("example") QCOrderDetailExample example);

    int updateByExample(@Param("record") QCOrderDetail record, @Param("example") QCOrderDetailExample example);

    int updateByPrimaryKeySelective(QCOrderDetail record);

    int updateByPrimaryKey(QCOrderDetail record);
}