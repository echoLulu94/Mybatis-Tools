package com.cmos.qrcode.dao.distribution;

import com.cmos.qrcode.beans.distribution.QCAgentGoods;
import com.cmos.qrcode.beans.distribution.QCAgentGoodsExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface QCAgentGoodsMapper {
    long countByExample(QCAgentGoodsExample example);

    int deleteByExample(QCAgentGoodsExample example);

    int deleteByPrimaryKey(String id);

    int insert(QCAgentGoods record);

    int insertSelective(QCAgentGoods record);

    List<QCAgentGoods> selectByExample(QCAgentGoodsExample example);

    QCAgentGoods selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") QCAgentGoods record, @Param("example") QCAgentGoodsExample example);

    int updateByExample(@Param("record") QCAgentGoods record, @Param("example") QCAgentGoodsExample example);

    int updateByPrimaryKeySelective(QCAgentGoods record);

    int updateByPrimaryKey(QCAgentGoods record);
}