package com.cmos.qrcode.dao.user;

import com.cmos.qrcode.beans.user.QcBalckList;
import com.cmos.qrcode.beans.user.QcBalckListExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface QcBalckListMapper {
    long countByExample(QcBalckListExample example);

    int deleteByExample(QcBalckListExample example);

    int deleteByPrimaryKey(String phoneNo);

    int insert(QcBalckList record);

    int insertSelective(QcBalckList record);

    List<QcBalckList> selectByExample(QcBalckListExample example);

    QcBalckList selectByPrimaryKey(String phoneNo);

    int updateByExampleSelective(@Param("record") QcBalckList record, @Param("example") QcBalckListExample example);

    int updateByExample(@Param("record") QcBalckList record, @Param("example") QcBalckListExample example);

    int updateByPrimaryKeySelective(QcBalckList record);

    int updateByPrimaryKey(QcBalckList record);
}